var words = [
	 "lua", "banana","web","ma�a", "prefer�ncia", "mo�a", "c�o"
	  ];